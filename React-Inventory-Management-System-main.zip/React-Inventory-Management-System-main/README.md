# React-Inventory-Management-System
Inventory Management System Built with React JS, Node JS, Express JS, MongoDB and Tailwind CSS.

# [<span style="color: blue;">View Live Preview from here.</span>](https://inventory-management-rosy.vercel.app)
